Pak GSM Repair — Bluetooth Test Android Project (ابتدائی ٹیسٹ ورژن)

یہ ZIP Android Studio کا سورس پروجیکٹ ہے، APK فائل نہیں۔ یہاں APK compile نہیں کی گئی، اس لیے اسے ابھی فون پر براہِ راست انسٹال نہیں کیا جا سکتا۔

یہ ٹیسٹ ایپ کیا کرتی ہے؟
1. Android کی Nearby devices اجازت مانگتی ہے۔
2. Bluetooth کی حالت دکھاتی ہے۔
3. پہلے سے paired Bluetooth devices کے نام/پتے دکھانے کی کوشش کرتی ہے۔
4. BLE کے اشتہارات 10 سیکنڈ تک scan کرتی ہے۔
5. کسی BLE ڈیوائس سے GATT کنکشن کرکے دستیاب services اور characteristics دکھاتی ہے۔
6. فون کی Bluetooth Settings کھولتی ہے۔

حدود:
- عام Bluetooth audio (A2DP) کے ذریعے ہیڈفون کا آڈیو کنکشن اس ٹیسٹ ایپ سے مکمل طور پر کنٹرول نہیں ہوتا؛ Android کی Bluetooth Settings استعمال کریں۔
- ANC / Transparency / ٹچ کنٹرول صرف اسی صورت میں ممکن ہوں گے جب ہیڈفون مناسب vendor protocol فراہم کرے۔
- کچھ BLE ڈیوائسز نام یا معلومات ظاہر نہیں کرتیں۔
- یہ ابتدائی سورس ہے؛ حقیقی فون اور Pro2 پر ٹیسٹ ضروری ہے۔

APK بنانے کا عمومی طریقہ:
1. کمپیوٹر پر Android Studio نصب کریں۔
2. ZIP extract کریں۔
3. Android Studio میں اس فولڈر کو Open کریں۔
4. Gradle sync مکمل ہونے دیں۔
5. Build > Build Bundle(s) / APK(s) > Build APK(s) منتخب کریں۔
6. APK عام طور پر app/build/outputs/apk/debug/app-debug.apk میں ملتی ہے۔

اگر صرف موبائل موجود ہے تو یہ سورس پروجیکٹ خود سے APK میں تبدیل نہیں ہوگا؛ اس کے لیے قابلِ اعتماد Android build environment درکار ہوگا۔
