package com.pakgsm.bluetoothtest

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var logView: TextView
    private lateinit var bluetoothAdapter: BluetoothAdapter
    private val handler = Handler(Looper.getMainLooper())
    private val seen = linkedMapOf<String, BluetoothDevice>()
    private var gatt: BluetoothGatt? = null
    private var scanning = false

    private val requiredPermissions: Array<String>
        get() = if (Build.VERSION.SDK_INT >= 31) arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT
        ) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = manager.adapter
        buildUi()
        if (!hasPermissions()) requestPermissions(requiredPermissions, 10)
        else showStatus()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(0xFFF7FAF9.toInt())
        }
        val title = TextView(this).apply {
            text = "Pak GSM Repair · Bluetooth Test"
            textSize = 22f
            setTextColor(0xFF115E59.toInt())
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text = "Native Android test · Nearby-device permission"
            textSize = 14f
        }
        root.addView(subtitle)
        addButton(root, "Check Bluetooth status") { showStatus() }
        addButton(root, "Show paired devices") { showPaired() }
        addButton(root, "Scan nearby BLE devices (10 sec)") { startBleScan() }
        addButton(root, "Open phone Bluetooth settings") {
            startActivity(android.content.Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS))
        }
        addButton(root, "Disconnect BLE device") {
            gatt?.disconnect()
            gatt?.close()
            gatt = null
            log("Disconnected and closed BLE connection.")
        }
        val scroll = ScrollView(this)
        logView = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFF17211F.toInt())
            setPadding(0, 16, 0, 24)
            text = "Ready. Grant Nearby devices permission, then scan."
        }
        scroll.addView(logView)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun addButton(root: LinearLayout, label: String, action: () -> Unit) {
        val button = Button(this).apply { text = label; setOnClickListener { action() } }
        root.addView(button, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun hasPermissions(): Boolean =
        requiredPermissions.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10) {
            if (hasPermissions()) showStatus()
            else log("Permission not granted. Allow Nearby devices to use scanning/connection.")
        }
    }

    @SuppressLint("MissingPermission")
    private fun showStatus() {
        if (!hasPermissions()) { requestPermissions(requiredPermissions, 10); return }
        log("Bluetooth supported: ${bluetoothAdapter.isEnabled || bluetoothAdapter.state == BluetoothAdapter.STATE_OFF}")
        log("Bluetooth enabled: ${bluetoothAdapter.isEnabled}")
        log("BLE scanner available: ${bluetoothAdapter.bluetoothLeScanner != null}")
        log("Android version: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
    }

    @SuppressLint("MissingPermission")
    private fun showPaired() {
        if (!hasPermissions()) { requestPermissions(requiredPermissions, 10); return }
        val devices = bluetoothAdapter.bondedDevices ?: emptySet()
        log("Paired devices: ${devices.size}")
        if (devices.isEmpty()) log("No paired devices found. Pair headphones in phone Bluetooth settings first.")
        devices.forEach { device ->
            val name = try { device.name ?: "(name not exposed)" } catch (_: SecurityException) { "(permission denied)" }
            log("• $name | ${device.address} | bond=${device.bondState}")
        }
    }

    @SuppressLint("MissingPermission")
    private fun startBleScan() {
        if (!hasPermissions()) { requestPermissions(requiredPermissions, 10); return }
        val scanner = bluetoothAdapter.bluetoothLeScanner
        if (!bluetoothAdapter.isEnabled) {
            log("Bluetooth is OFF. Turn it on in phone settings first.")
            startActivity(android.content.Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS))
            return
        }
        if (scanner == null) { log("BLE scanner unavailable on this device."); return }
        if (scanning) { log("Scan already running."); return }
        seen.clear()
        scanning = true
        log("Scanning nearby BLE advertisements for 10 seconds…")
        try {
            scanner.startScan(scanCallback)
            handler.postDelayed({
                try { scanner.stopScan(scanCallback) } catch (_: Exception) {}
                scanning = false
                log("Scan finished. Unique BLE devices found: ${seen.size}")
                if (seen.isEmpty()) log("No BLE advertisements found. Some audio headphones do not advertise while connected or may not expose BLE.")
            }, 10_000)
        } catch (e: Exception) {
            scanning = false
            log("Scan failed: ${e.message}")
        }
    }

    private val scanCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            val key = d.address ?: return
            if (!seen.containsKey(key)) {
                seen[key] = d
                val name = try { d.name ?: result.scanRecord?.deviceName ?: "(unnamed BLE device)" } catch (_: SecurityException) { "(name hidden)" }
                runOnUiThread {
                    log("BLE: $name | $key | RSSI ${result.rssi} dBm")
                    addConnectButton(name, d)
                }
            }
        }
        override fun onScanFailed(errorCode: Int) {
            scanning = false
            runOnUiThread { log("BLE scan failed, error code $errorCode") }
        }
    }

    private fun addConnectButton(name: String, device: BluetoothDevice) {
        val button = Button(this).apply {
            text = "Connect BLE: $name"
            setOnClickListener { connectGatt(device) }
        }
        val root = (findViewById<ViewGroup>(android.R.id.content).getChildAt(0) as? LinearLayout)
        root?.addView(button, root.indexOfChild(logView.parent as? android.view.View ?: logView).coerceAtLeast(0))
    }

    @SuppressLint("MissingPermission")
    private fun connectGatt(device: BluetoothDevice) {
        if (!hasPermissions()) { requestPermissions(requiredPermissions, 10); return }
        gatt?.close()
        log("Connecting to BLE GATT: ${device.address}")
        gatt = device.connectGatt(this, false, object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
                runOnUiThread {
                    if (newState == android.bluetooth.BluetoothProfile.STATE_CONNECTED) {
                        log("BLE GATT connected (status=$status). Discovering services…")
                        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) return@runOnUiThread
                        g.discoverServices()
                    } else if (newState == android.bluetooth.BluetoothProfile.STATE_DISCONNECTED) {
                        log("BLE GATT disconnected (status=$status).")
                    }
                }
            }
            override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
                runOnUiThread {
                    log("Service discovery status=$status; services=${g.services.size}")
                    g.services.forEach { service ->
                        log("SERVICE ${service.uuid} (${service.typeName()})")
                        service.characteristics.forEach { characteristic ->
                            log("  CHAR ${characteristic.uuid} properties=${properties(characteristic)}")
                        }
                    }
                    log("Note: service listing does not guarantee headphone controls are supported.")
                }
            }
            override fun onCharacteristicRead(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
                @Suppress("DEPRECATION")
                val bytes = characteristic.value
                runOnUiThread { log("READ ${characteristic.uuid}: status=$status value=${bytes?.joinToString(" ") { "%02X".format(it) } ?: "(empty)"}") }
            }
        }, BluetoothDevice.TRANSPORT_LE)
    }

    private fun BluetoothGattService.typeName() = if (type == BluetoothGattService.SERVICE_TYPE_PRIMARY) "primary" else "secondary"

    private fun properties(c: BluetoothGattCharacteristic): String {
        val p = c.properties
        val names = mutableListOf<String>()
        if (p and BluetoothGattCharacteristic.PROPERTY_READ != 0) names += "READ"
        if (p and BluetoothGattCharacteristic.PROPERTY_WRITE != 0) names += "WRITE"
        if (p and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0) names += "WRITE_NO_RESPONSE"
        if (p and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0) names += "NOTIFY"
        if (p and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) names += "INDICATE"
        return names.joinToString(",").ifEmpty { "none" }
    }

    private fun log(message: String) {
        runOnUiThread { logView.append("\n$message") }
    }

    override fun onDestroy() {
        try { gatt?.disconnect(); gatt?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
